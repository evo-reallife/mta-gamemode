rootElement = getRootElement()
thisResource = getThisResource()
thisResourceRoot = getResourceRootElement(thisResource)
thisDynamicRoot = getResourceDynamicElementRoot(thisResource)

-- DEBUG ONLY! Set to true for extended saving and loading times (medium sized maps)
DEBUG_LOADSAVE = false
